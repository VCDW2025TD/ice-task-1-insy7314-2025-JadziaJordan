// src/App.jsx
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./components/HomePage";
import Register from "./components/Register";
import Login from "./components/Login";
import DashboardPage from "./components/DashboardPage";
import ProtectedRoute from "./components/ProtectedRoute";
import LogoutPage from "./components/Logout";
import NavBar from "./components/NavBar";
import SecurityDemo from "./SecurityDemo"; // Add the CSP demo

function App() {
  return (
    <Router>
      {/* Navbar visible on all pages */}
      <NavBar />

      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />

        {/* Protected Dashboard route */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          }
        />

        {/* Logout route */}
        <Route path="/logout" element={<LogoutPage />} />

        {/* CSP Test route */}
        <Route path="/security-demo" element={<SecurityDemo />} />
      </Routes>
    </Router>
  );
}

export default App;
