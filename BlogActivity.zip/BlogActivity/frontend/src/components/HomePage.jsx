// src/components/HomePage.jsx
import React from "react";
import './HomePage.css';
import { Link } from "react-router-dom";

const HomePage = () => {
  return (
    <div className="home-hero">
      <div className="home-content">
        <h1>Welcome to My Blog</h1>
        <p>Share your thoughts, connect with others, and explore new ideas!</p>
        <div className="home-buttons">
          <Link to="/register" className="btn">Get Started</Link>
          <Link to="/login" className="btn btn-secondary">Login</Link>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
