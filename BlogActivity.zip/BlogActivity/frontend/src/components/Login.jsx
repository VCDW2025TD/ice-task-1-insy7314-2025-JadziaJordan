// src/components/Login.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { isValidEmail, isStrongPassword } from "../utils/validators";
import "./Login.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    // --- Frontend validation ---
    if (!email || !password) {
      setMessage("Email and password are required.");
      return;
    }

    if (!isValidEmail(email)) {
      setMessage("Invalid email format.");
      return;
    }

    if (!isStrongPassword(password)) {
      setMessage(
        "Password must be at least 8 characters and include letters and numbers."
      );
      return;
    }

    // --- Backend request ---
    try {
      const response = await axios.post(
        "https://localhost:5000/api/auth/login",
        { email, password },
        { headers: { "Content-Type": "application/json" } }
      );

      // Save JWT token
      localStorage.setItem("token", response.data.token);
      setMessage("Login successful!");

      // Redirect to dashboard
      navigate("/dashboard");
    } catch (error) {
      // Show generic message for invalid credentials
      if (error.response && error.response.status === 401) {
        setMessage("Invalid credentials");
      } else {
        setMessage("Login failed. Try again later.");
      }
    }
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <h2>Login</h2>

        {/* Show message */}
        {message && (
          <p className={`message ${message.includes("successful") ? "success" : "error"}`}>
            {message}
          </p>
        )}

        <form className="login-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={8} // match frontend validator
            />
          </div>

          <button type="submit">Login</button>
        </form>
      </div>
    </div>
  );
};

export default Login;
