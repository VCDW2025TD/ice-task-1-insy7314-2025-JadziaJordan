// src/components/ProtectedRoute.jsx
import React from "react";
import { Navigate } from "react-router-dom";

// This component wraps around any route you want protected
const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem("token"); // check if JWT exists

  if (!token) {
    // If no token, redirect to login page
    alert("You must log in first"); // optional alert for feedback
    return <Navigate to="/login" replace />;
  }

  // If token exists, render the protected component
  return children;
};

export default ProtectedRoute;
