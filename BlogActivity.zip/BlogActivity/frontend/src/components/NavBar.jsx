// src/components/NavBar.jsx
import { Link } from "react-router-dom";
import './NavBar.css';

const NavBar = () => {
  const isLoggedIn = !!localStorage.getItem("token");

  return (
    <nav className="navbar">
      <div className="nav-container">
        <Link to="/" className="nav-logo">MyBlog</Link>
        <div className="nav-links">
          <Link to="/">Home</Link>
          {!isLoggedIn && <Link to="/register">Register</Link>}
          {!isLoggedIn && <Link to="/login">Login</Link>}
          {isLoggedIn && <Link to="/dashboard">Dashboard</Link>}
          {isLoggedIn && <Link to="/logout">Logout</Link>}
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
