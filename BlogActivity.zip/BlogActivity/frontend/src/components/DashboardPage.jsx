// src/components/DashboardPage.jsx
import React from "react";
import "./DashboardPage.css";

const DashboardPage = () => {
  return (
    <div className="dashboard-page">
      <div className="dashboard-container">
        <h2>Dashboard</h2>
        <p>Welcome! You are logged in and can access this protected content.</p>
        <p>Use the navigation bar above to explore the app.</p>
      </div>
    </div>
  );
};

export default DashboardPage;
